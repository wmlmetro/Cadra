# -*- coding: utf-8 -*-
{
    'name': 'NRS Location Sync',
    'version': '15.0.1.0.0',
    'summary': 'Syncs generic.location with fleet vehicle locations and adds location to ITSM requests',
    'description': """
NRS Location Sync
=================
- Keeps generic.location (CRND) in sync with fleet.vehicle location field
- Adds location_id Many2one field to request.request (ITSM)
- Exposes location dropdown on the ITSM request form and portal
- Bidirectional sync via ORM overrides (create/write/unlink hooks)
    """,
    'author': 'WestMetro Limited',
    'website': 'https://westmetrong.com',
    'category': 'Technical',
    'license': 'LGPL-3',
    'depends': [
        'generic_location',   # CRND generic location module
        'generic_resource',   # CRND generic resource module
        'generic_request',    # CRND ITSM request module
        'fleet',              # Odoo fleet module
    ],
    'data': [
        'security/ir.model.access.csv',
        'views/generic_location_views.xml',
        'views/fleet_vehicle_views.xml',
        'views/fleet_vehicle_resource_views.xml',
        'views/request_request_views.xml',
        'views/portal_request_templates.xml',
    ],
    'installable': True,
    'auto_install': False,
    'application': False,
}
