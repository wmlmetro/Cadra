# -*- coding: utf-8 -*-
from . import generic_location
from . import fleet_vehicle
from . import fleet_vehicle_resource
from . import request_request
