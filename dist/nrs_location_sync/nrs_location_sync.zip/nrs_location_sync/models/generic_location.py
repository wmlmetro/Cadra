# -*- coding: utf-8 -*-
"""
generic_location.py
-------------------
Extends generic.location to carry a reference to the corresponding
fleet.vehicle.location record, and drives the MASTER → REPLICA sync.

generic.location  (MASTER)
        │
        │  on create/write/unlink
        ▼
fleet.vehicle.location  (REPLICA)

The fleet side (fleet_vehicle.py) drives the reverse direction.
A _sync_in_progress flag on the environment context prevents recursion.
"""

import logging
from odoo import models, fields, api, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

# Context key used as a re-entrancy guard across both sync directions
SYNC_CTX = 'nrs_location_sync_in_progress'


class GenericLocation(models.Model):
    _inherit = 'generic.location'

    # ------------------------------------------------------------------ #
    #  Back-reference to the mirrored fleet.vehicle.location record       #
    # ------------------------------------------------------------------ #
    fleet_location_id = fields.Many2one(
        comodel_name='fleet.vehicle.location',
        string='Fleet Location Mirror',
        ondelete='set null',
        copy=False,
        help="The fleet.vehicle.location record that mirrors this location. "
             "Managed automatically — do not edit manually.",
    )

    # ------------------------------------------------------------------ #
    #  Helpers                                                             #
    # ------------------------------------------------------------------ #
    def _fleet_location_vals(self):
        """Return dict of fleet.vehicle.location field values for this record."""
        self.ensure_one()
        return {'name': self.name}

    def _get_or_create_fleet_location(self):
        """
        Return the linked fleet.vehicle.location, creating it if absent.
        Always called from within a SYNC_CTX guard so no recursion occurs.
        """
        self.ensure_one()
        FleetLoc = self.env['fleet.vehicle.location']

        if self.fleet_location_id:
            return self.fleet_location_id

        # Try to find an existing fleet location with the same name
        existing = FleetLoc.search([('name', '=', self.name)], limit=1)
        if existing:
            self.with_context(**{SYNC_CTX: True}).write(
                {'fleet_location_id': existing.id}
            )
            return existing

        # Create a new fleet location
        fleet_loc = FleetLoc.with_context(**{SYNC_CTX: True}).create(
            self._fleet_location_vals()
        )
        self.with_context(**{SYNC_CTX: True}).write(
            {'fleet_location_id': fleet_loc.id}
        )
        return fleet_loc

    # ------------------------------------------------------------------ #
    #  ORM overrides — push changes to fleet.vehicle.location             #
    # ------------------------------------------------------------------ #
    @api.model_create_multi
    def create(self, vals_list):
        records = super().create(vals_list)
        if not self.env.context.get(SYNC_CTX):
            records.with_context(**{SYNC_CTX: True})._sync_to_fleet()
        return records

    def write(self, vals):
        result = super().write(vals)
        if not self.env.context.get(SYNC_CTX) and 'name' in vals:
            self.with_context(**{SYNC_CTX: True})._sync_to_fleet()
        return result

    def unlink(self):
        # Archive the fleet mirror rather than delete — preserves vehicle history
        fleet_locs = self.mapped('fleet_location_id')
        result = super().unlink()
        if fleet_locs:
            fleet_locs.with_context(**{SYNC_CTX: True}).write({'active': False})
        return result

    # ------------------------------------------------------------------ #
    #  Sync engine                                                         #
    # ------------------------------------------------------------------ #
    def _sync_to_fleet(self):
        """
        Push name changes (and create mirrors for new records) to
        fleet.vehicle.location.  Safe to call in bulk.
        """
        for loc in self:
            fleet_loc = loc._get_or_create_fleet_location()
            if fleet_loc.name != loc.name:
                fleet_loc.with_context(**{SYNC_CTX: True}).write(
                    {'name': loc.name}
                )
                _logger.debug(
                    "NRS location sync: generic.location[%s] → "
                    "fleet.vehicle.location[%s] name='%s'",
                    loc.id, fleet_loc.id, loc.name,
                )

    # ------------------------------------------------------------------ #
    #  Manual sync action (available from the list/form view)             #
    # ------------------------------------------------------------------ #
    def action_sync_to_fleet(self):
        """
        Manual trigger: synchronise selected generic.location records
        to fleet.vehicle.location.  Shows a result notification.
        """
        if not self:
            raise UserError(_("Please select at least one location to sync."))
        self.with_context(**{SYNC_CTX: True})._sync_to_fleet()
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _("Sync Complete"),
                'message': _(
                    "%d location(s) synchronised to Fleet."
                ) % len(self),
                'type': 'success',
                'sticky': False,
            },
        }

    # ------------------------------------------------------------------ #
    #  Full re-sync utility (called from Settings or shell)               #
    # ------------------------------------------------------------------ #
    @api.model
    def action_full_resync(self):
        """
        Re-sync ALL active generic.location records to fleet.vehicle.location.
        Safe to run multiple times (idempotent).
        Accessible via: Settings → Technical → NRS → Full Location Re-Sync
        """
        all_locs = self.search([])
        _logger.info(
            "NRS location sync: starting full re-sync for %d locations",
            len(all_locs),
        )
        all_locs.with_context(**{SYNC_CTX: True})._sync_to_fleet()
        _logger.info("NRS location sync: full re-sync complete")
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _("Full Re-Sync Complete"),
                'message': _(
                    "All %d locations synchronised between Generic Location "
                    "and Fleet."
                ) % len(all_locs),
                'type': 'success',
                'sticky': True,
            },
        }
