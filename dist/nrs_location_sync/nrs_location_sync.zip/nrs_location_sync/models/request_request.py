# -*- coding: utf-8 -*-
"""
request_request.py
------------------
Extends request.request (CRND generic_request) with a location_id field
so that every ITSM request is tagged to a specific NRS facility location.

The field is:
  - A Many2one to generic.location
  - Shown as a required dropdown on the backend form
  - Shown on the portal submission form
  - Included in email notification context
  - Filterable and groupable in list/kanban views
"""

from odoo import models, fields, api, _


class RequestRequest(models.Model):
    _inherit = 'request.request'

    location_id = fields.Many2one(
        comodel_name='generic.location',
        string='Location',
        index=True,
        tracking=True,
        help="The NRS facility location this request relates to.",
    )

    # Convenience: full location path as a char for display/search
    location_display_name = fields.Char(
        string='Location Path',
        compute='_compute_location_display_name',
        store=True,
        help="Full hierarchical path of the location (e.g. Abuja HQ / Block C / Room 204).",
    )

    @api.depends('location_id', 'location_id.complete_name')
    def _compute_location_display_name(self):
        for rec in self:
            if rec.location_id:
                # generic.location may expose complete_name (parent / child)
                # fall back to name if the field isn't present
                rec.location_display_name = getattr(
                    rec.location_id, 'complete_name', rec.location_id.name
                )
            else:
                rec.location_display_name = False
