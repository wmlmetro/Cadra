# -*- coding: utf-8 -*-
"""
fleet_vehicle.py
----------------
Extends fleet.vehicle.location to drive the REPLICA → MASTER reverse sync,
and adds location_id to fleet.vehicle for direct vehicle ↔ location linkage.

fleet.vehicle.location  (REPLICA — edits here propagate back to MASTER)
        │
        │  on write (name change)
        ▼
generic.location  (MASTER — updated to match)

fleet.vehicle gets a location_id field pointing at generic.location
so that vehicle records are linked into the unified location tree.
"""

import logging
from odoo import models, fields, api, _

_logger = logging.getLogger(__name__)

# Re-import the same context key so both files share one constant
from .generic_location import SYNC_CTX


class FleetVehicleLocation(models.Model):
    _inherit = 'fleet.vehicle.location'

    # ------------------------------------------------------------------ #
    #  ORM overrides — push name changes back to generic.location         #
    # ------------------------------------------------------------------ #
    def write(self, vals):
        result = super().write(vals)
        if not self.env.context.get(SYNC_CTX) and 'name' in vals:
            self.with_context(**{SYNC_CTX: True})._sync_to_generic()
        return result

    def unlink(self):
        # Find linked generic.location records and archive them too
        GenLoc = self.env['generic.location']
        gen_locs = GenLoc.search([('fleet_location_id', 'in', self.ids)])
        result = super().unlink()
        if gen_locs:
            gen_locs.with_context(**{SYNC_CTX: True}).write({'active': False})
        return result

    # ------------------------------------------------------------------ #
    #  Sync engine                                                         #
    # ------------------------------------------------------------------ #
    def _sync_to_generic(self):
        """
        For each fleet.vehicle.location that has a linked generic.location,
        push the updated name back.  If no generic.location exists yet,
        create one so the record appears in the unified tree.
        """
        GenLoc = self.env['generic.location']
        for fleet_loc in self:
            gen_loc = GenLoc.search(
                [('fleet_location_id', '=', fleet_loc.id)], limit=1
            )
            if gen_loc:
                if gen_loc.name != fleet_loc.name:
                    gen_loc.with_context(**{SYNC_CTX: True}).write(
                        {'name': fleet_loc.name}
                    )
                    _logger.debug(
                        "NRS location sync: fleet.vehicle.location[%s] → "
                        "generic.location[%s] name='%s'",
                        fleet_loc.id, gen_loc.id, fleet_loc.name,
                    )
            else:
                # No matching generic.location — create one and link it
                new_gen = GenLoc.with_context(**{SYNC_CTX: True}).create(
                    {'name': fleet_loc.name}
                )
                new_gen.with_context(**{SYNC_CTX: True}).write(
                    {'fleet_location_id': fleet_loc.id}
                )
                _logger.info(
                    "NRS location sync: created generic.location[%s] "
                    "from fleet.vehicle.location[%s] name='%s'",
                    new_gen.id, fleet_loc.id, fleet_loc.name,
                )

    # ------------------------------------------------------------------ #
    #  Manual sync action                                                  #
    # ------------------------------------------------------------------ #
    def action_sync_to_generic(self):
        self.with_context(**{SYNC_CTX: True})._sync_to_generic()
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _("Sync Complete"),
                'message': _(
                    "%d fleet location(s) synchronised to Generic Locations."
                ) % len(self),
                'type': 'success',
                'sticky': False,
            },
        }


class FleetVehicle(models.Model):
    _inherit = 'fleet.vehicle'

    # ------------------------------------------------------------------ #
    #  Location field — links vehicles into the unified location tree     #
    # ------------------------------------------------------------------ #
    location_id = fields.Many2one(
        comodel_name='generic.location',
        string='Location',
        index=True,
        tracking=True,
        help="The NRS facility location where this vehicle is normally "
             "stationed or assigned.",
    )

    # Convenience computed field showing the fleet.vehicle.location name
    # alongside the generic.location — kept for backward compatibility with
    # any existing fleet reports that used the old location_id on fleet.vehicle
    fleet_location_mirror_id = fields.Many2one(
        comodel_name='fleet.vehicle.location',
        string='Fleet Location (mirror)',
        related='location_id.fleet_location_id',
        store=True,
        readonly=True,
        help="Auto-populated from the linked generic.location. "
             "Used by fleet reports and filters.",
    )
