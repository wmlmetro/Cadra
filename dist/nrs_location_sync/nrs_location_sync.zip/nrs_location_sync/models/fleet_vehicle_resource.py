# -*- coding: utf-8 -*-
"""
fleet_vehicle_resource.py
─────────────────────────
Syncs fleet vehicles into the Generic Resource module.

Mapping:
  fleet.vehicle.tag   ──►  generic.resource.category
      (vehicle tags           (resource categories —
       used as categories)     "NRS Fleet" parent)

  fleet.vehicle       ──►  generic.resource
      (each vehicle           (each vehicle as a
       becomes a resource)     typed resource)

Sync direction:
  - fleet.vehicle.tag  create/write/unlink  →  generic.resource.category
  - generic.resource.category write/unlink  →  fleet.vehicle.tag  (reverse)
  - fleet.vehicle      create/write/unlink  →  generic.resource
  - generic.resource   write/unlink         →  fleet.vehicle      (reverse)

A single "NRS Fleet Vehicles" parent category is created in
generic.resource.category to group all vehicle categories under one node.

A single generic.resource.type is registered pointing at fleet.vehicle
so that each generic.resource record hyperlinks back to the vehicle form.

Context guard:  nrs_fleet_resource_sync_in_progress
"""

import logging
from odoo import models, fields, api, _

_logger = logging.getLogger(__name__)

SYNC_CTX = 'nrs_fleet_resource_sync_in_progress'

# XML-ID we use to anchor the parent category and resource type
# (created programmatically on first run)
PARENT_CATEGORY_XMLID  = 'nrs_location_sync.resource_category_nrs_fleet'
RESOURCE_TYPE_XMLID    = 'nrs_location_sync.resource_type_fleet_vehicle'


# ═══════════════════════════════════════════════════════════════════════════
#  HELPERS  (module-level so both classes share them)
# ═══════════════════════════════════════════════════════════════════════════

def _get_or_create_parent_category(env):
    """
    Return (or lazily create) the top-level 'NRS Fleet Vehicles'
    generic.resource.category that all vehicle tag categories sit under.
    """
    IrModelData = env['ir.model.data']
    ResCategory  = env['generic.resource.category']

    try:
        rec = env.ref(PARENT_CATEGORY_XMLID)
        return rec
    except ValueError:
        pass

    parent = ResCategory.with_context(**{SYNC_CTX: True}).create({
        'name': 'NRS Fleet Vehicles',
    })
    # Register a stable xml-id so we find it next time
    IrModelData.create({
        'name':    'resource_category_nrs_fleet',
        'module':  'nrs_location_sync',
        'model':   'generic.resource.category',
        'res_id':  parent.id,
        'noupdate': True,
    })
    _logger.info("NRS fleet-resource sync: created parent category id=%s", parent.id)
    return parent


def _get_or_create_resource_type(env):
    """
    Return (or lazily create) a generic.resource.type whose model is
    fleet.vehicle.  This allows clicking through from a generic.resource
    record directly to the vehicle form.
    """
    IrModelData = env['ir.model.data']
    ResType      = env['generic.resource.type']
    IrModel      = env['ir.model']

    try:
        return env.ref(RESOURCE_TYPE_XMLID)
    except ValueError:
        pass

    fleet_model = IrModel.search([('model', '=', 'fleet.vehicle')], limit=1)
    if not fleet_model:
        _logger.warning("NRS fleet-resource sync: fleet.vehicle model not found")
        return None

    res_type = ResType.with_context(**{SYNC_CTX: True}).create({
        'name':     'NRS Fleet Vehicle',
        'model_id': fleet_model.id,
    })
    IrModelData.create({
        'name':    'resource_type_fleet_vehicle',
        'module':  'nrs_location_sync',
        'model':   'generic.resource.type',
        'res_id':  res_type.id,
        'noupdate': True,
    })
    _logger.info("NRS fleet-resource sync: created resource type id=%s", res_type.id)
    return res_type


# ═══════════════════════════════════════════════════════════════════════════
#  fleet.vehicle.tag  ←→  generic.resource.category
# ═══════════════════════════════════════════════════════════════════════════

class FleetVehicleTag(models.Model):
    _inherit = 'fleet.vehicle.tag'

    resource_category_id = fields.Many2one(
        comodel_name='generic.resource.category',
        string='Resource Category Mirror',
        ondelete='set null',
        copy=False,
        help="Linked generic.resource.category record. Managed automatically.",
    )

    # ── helpers ────────────────────────────────────────────────────────────

    def _resource_category_vals(self):
        self.ensure_one()
        parent = _get_or_create_parent_category(self.env)
        return {
            'name':      self.name,
            'parent_id': parent.id,
        }

    def _get_or_create_resource_category(self):
        self.ensure_one()
        ResCategory = self.env['generic.resource.category']

        if self.resource_category_id:
            return self.resource_category_id

        existing = ResCategory.search([
            ('name', '=', self.name),
            ('parent_id', '=', _get_or_create_parent_category(self.env).id),
        ], limit=1)
        if existing:
            self.with_context(**{SYNC_CTX: True}).write(
                {'resource_category_id': existing.id}
            )
            return existing

        cat = ResCategory.with_context(**{SYNC_CTX: True}).create(
            self._resource_category_vals()
        )
        self.with_context(**{SYNC_CTX: True}).write(
            {'resource_category_id': cat.id}
        )
        return cat

    # ── ORM hooks ──────────────────────────────────────────────────────────

    @api.model_create_multi
    def create(self, vals_list):
        records = super().create(vals_list)
        if not self.env.context.get(SYNC_CTX):
            records.with_context(**{SYNC_CTX: True})._sync_tag_to_category()
        return records

    def write(self, vals):
        result = super().write(vals)
        if not self.env.context.get(SYNC_CTX) and 'name' in vals:
            self.with_context(**{SYNC_CTX: True})._sync_tag_to_category()
        return result

    def unlink(self):
        cats = self.mapped('resource_category_id')
        result = super().unlink()
        if cats:
            cats.with_context(**{SYNC_CTX: True}).write({'active': False})
        return result

    # ── sync engine ────────────────────────────────────────────────────────

    def _sync_tag_to_category(self):
        for tag in self:
            cat = tag._get_or_create_resource_category()
            if cat.name != tag.name:
                cat.with_context(**{SYNC_CTX: True}).write({'name': tag.name})
                _logger.debug(
                    "NRS fleet-resource: tag[%s] → category[%s] name='%s'",
                    tag.id, cat.id, tag.name,
                )

    def action_sync_to_resource_category(self):
        self.with_context(**{SYNC_CTX: True})._sync_tag_to_category()
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _("Sync Complete"),
                'message': _("%d tag(s) synced to Resource Categories.") % len(self),
                'type': 'success',
                'sticky': False,
            },
        }


# ═══════════════════════════════════════════════════════════════════════════
#  generic.resource.category  →  fleet.vehicle.tag  (reverse)
# ═══════════════════════════════════════════════════════════════════════════

class GenericResourceCategory(models.Model):
    _inherit = 'generic.resource.category'

    def write(self, vals):
        result = super().write(vals)
        if not self.env.context.get(SYNC_CTX) and 'name' in vals:
            self.with_context(**{SYNC_CTX: True})._sync_category_to_tag()
        return result

    def unlink(self):
        FleetTag = self.env['fleet.vehicle.tag']
        tags = FleetTag.search([('resource_category_id', 'in', self.ids)])
        result = super().unlink()
        # Don't delete tags — just clear the mirror link
        if tags:
            tags.with_context(**{SYNC_CTX: True}).write(
                {'resource_category_id': False}
            )
        return result

    def _sync_category_to_tag(self):
        FleetTag = self.env['fleet.vehicle.tag']
        for cat in self:
            tag = FleetTag.search(
                [('resource_category_id', '=', cat.id)], limit=1
            )
            if tag and tag.name != cat.name:
                tag.with_context(**{SYNC_CTX: True}).write({'name': cat.name})
                _logger.debug(
                    "NRS fleet-resource: category[%s] → tag[%s] name='%s'",
                    cat.id, tag.id, cat.name,
                )


# ═══════════════════════════════════════════════════════════════════════════
#  fleet.vehicle  ←→  generic.resource
# ═══════════════════════════════════════════════════════════════════════════

class FleetVehicleResource(models.Model):
    _inherit = 'fleet.vehicle'

    resource_id = fields.Many2one(
        comodel_name='generic.resource',
        string='Generic Resource Mirror',
        ondelete='set null',
        copy=False,
        help="Linked generic.resource record. Managed automatically.",
    )

    # ── helpers ────────────────────────────────────────────────────────────

    def _resource_vals(self):
        """
        Build values for generic.resource from this vehicle.
        Name: 'BRAND MODEL (PLATE)' — descriptive and unique.
        Category: first tag's resource category, else parent NRS Fleet category.
        """
        self.ensure_one()
        res_type = _get_or_create_resource_type(self.env)

        # Derive category from the first vehicle tag that has a mirror
        category = None
        for tag in self.tag_ids:
            if tag.resource_category_id:
                category = tag.resource_category_id
                break
        if not category:
            category = _get_or_create_parent_category(self.env)

        # Build a readable name
        parts = []
        if self.brand_id:
            parts.append(self.brand_id.name)
        if self.model_id:
            parts.append(self.model_id.name)
        if self.license_plate:
            parts.append(f"({self.license_plate})")
        name = ' '.join(parts) if parts else (self.name or f"Vehicle {self.id}")

        vals = {
            'name':        name,
            'category_id': category.id,
        }
        if res_type:
            vals['resource_type_id'] = res_type.id
            vals['resource_ref']     = f'fleet.vehicle,{self.id}'
        return vals

    def _get_or_create_resource(self):
        self.ensure_one()
        GenResource = self.env['generic.resource']

        if self.resource_id:
            return self.resource_id

        # Search for an existing resource pointing at this vehicle
        existing = GenResource.search([
            ('resource_ref', '=', f'fleet.vehicle,{self.id}')
        ], limit=1)
        if existing:
            self.with_context(**{SYNC_CTX: True}).write(
                {'resource_id': existing.id}
            )
            return existing

        resource = GenResource.with_context(**{SYNC_CTX: True}).create(
            self._resource_vals()
        )
        self.with_context(**{SYNC_CTX: True}).write(
            {'resource_id': resource.id}
        )
        return resource

    # ── ORM hooks ──────────────────────────────────────────────────────────

    @api.model_create_multi
    def create(self, vals_list):
        records = super().create(vals_list)
        if not self.env.context.get(SYNC_CTX):
            records.with_context(**{SYNC_CTX: True})._sync_vehicle_to_resource()
        return records

    def write(self, vals):
        result = super().write(vals)
        sync_fields = {'license_plate', 'brand_id', 'model_id', 'tag_ids', 'name'}
        if not self.env.context.get(SYNC_CTX) and sync_fields & set(vals):
            self.with_context(**{SYNC_CTX: True})._sync_vehicle_to_resource()
        return result

    def unlink(self):
        resources = self.mapped('resource_id')
        result = super().unlink()
        if resources:
            resources.with_context(**{SYNC_CTX: True}).write({'active': False})
        return result

    # ── sync engine ────────────────────────────────────────────────────────

    def _sync_vehicle_to_resource(self):
        for vehicle in self:
            resource = vehicle._get_or_create_resource()
            new_vals  = vehicle._resource_vals()
            dirty = {
                k: v for k, v in new_vals.items()
                if getattr(resource, k, None) != v
                and k not in ('resource_ref',)   # ref is set on create only
            }
            if dirty:
                resource.with_context(**{SYNC_CTX: True}).write(dirty)
                _logger.debug(
                    "NRS fleet-resource: vehicle[%s] → resource[%s] %s",
                    vehicle.id, resource.id, list(dirty.keys()),
                )

    def action_sync_to_resource(self):
        self.with_context(**{SYNC_CTX: True})._sync_vehicle_to_resource()
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _("Sync Complete"),
                'message': _(
                    "%d vehicle(s) synced to Generic Resources."
                ) % len(self),
                'type': 'success',
                'sticky': False,
            },
        }


# ═══════════════════════════════════════════════════════════════════════════
#  generic.resource  →  fleet.vehicle  (reverse — name changes only)
# ═══════════════════════════════════════════════════════════════════════════

class GenericResource(models.Model):
    _inherit = 'generic.resource'

    def write(self, vals):
        result = super().write(vals)
        if not self.env.context.get(SYNC_CTX) and 'category_id' in vals:
            self.with_context(**{SYNC_CTX: True})._sync_resource_category_to_vehicle()
        return result

    def _sync_resource_category_to_vehicle(self):
        """
        If a resource's category is changed manually in the resource module,
        update the vehicle's tag_ids to include the tag linked to the new category.
        """
        FleetVehicle = self.env['fleet.vehicle']
        FleetTag     = self.env['fleet.vehicle.tag']

        for resource in self:
            vehicle = FleetVehicle.search(
                [('resource_id', '=', resource.id)], limit=1
            )
            if not vehicle:
                continue
            # Find the tag linked to the new category
            tag = FleetTag.search(
                [('resource_category_id', '=', resource.category_id.id)],
                limit=1,
            )
            if tag and tag not in vehicle.tag_ids:
                vehicle.with_context(**{SYNC_CTX: True}).write(
                    {'tag_ids': [(4, tag.id)]}
                )
                _logger.debug(
                    "NRS fleet-resource: resource[%s] category changed → "
                    "vehicle[%s] tag added [%s]",
                    resource.id, vehicle.id, tag.name,
                )
