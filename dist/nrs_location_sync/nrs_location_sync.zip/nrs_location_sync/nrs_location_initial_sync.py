#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
nrs_location_initial_sync.py
─────────────────────────────
One-time migration script.  Run this AFTER installing nrs_location_sync
to cross-link all pre-existing generic.location and fleet.vehicle.location
records and populate location_id on fleet.vehicle records.

Usage (run from server):
    cd /opt/odoo && sudo -u odoo /opt/odoo/venv/bin/python3 odoo/odoo-bin shell \\
        -c /opt/odoo/conf/odoo.conf -d myservice.com.ng --no-http \\
        < /root/CRND/nrs_location_initial_sync.py

Safe to run multiple times — fully idempotent.
"""

import logging
_logger = logging.getLogger('nrs_location_sync')

SYNC_CTX = 'nrs_location_sync_in_progress'

print("=" * 60)
print("NRS Location Initial Sync")
print("=" * 60)

GenLoc  = env['generic.location']
FleetLoc = env['fleet.vehicle.location']
Vehicle  = env['fleet.vehicle']

# ── STEP 1: Match existing records by name ──────────────────────────────
print("\n[1/4] Matching existing locations by name...")

fleet_locs = FleetLoc.search([])
gen_locs   = GenLoc.search([])

fleet_by_name = {fl.name.strip().lower(): fl for fl in fleet_locs}
gen_by_name   = {gl.name.strip().lower(): gl for gl in gen_locs}

matched = 0
created_gen = 0
created_fleet = 0

# Match fleet → generic
for name_key, fleet_loc in fleet_by_name.items():
    gen_loc = gen_by_name.get(name_key)
    if gen_loc:
        # Link them
        if not gen_loc.fleet_location_id:
            gen_loc.with_context(**{SYNC_CTX: True}).write(
                {'fleet_location_id': fleet_loc.id}
            )
            matched += 1
            print(f"  ✓ Linked: '{fleet_loc.name}'  [fleet:{fleet_loc.id} ↔ generic:{gen_loc.id}]")
    else:
        # Fleet location has no generic.location counterpart — create one
        new_gen = GenLoc.with_context(**{SYNC_CTX: True}).create(
            {'name': fleet_loc.name}
        )
        new_gen.with_context(**{SYNC_CTX: True}).write(
            {'fleet_location_id': fleet_loc.id}
        )
        created_gen += 1
        print(f"  + Created generic.location '{fleet_loc.name}'  [generic:{new_gen.id}]")

# Generic locations that have no fleet counterpart — create fleet mirror
for name_key, gen_loc in gen_by_name.items():
    if not gen_loc.fleet_location_id:
        # Check if a fleet loc exists now (may have been created above)
        fleet_loc = FleetLoc.search([('name', 'ilike', gen_loc.name)], limit=1)
        if fleet_loc:
            gen_loc.with_context(**{SYNC_CTX: True}).write(
                {'fleet_location_id': fleet_loc.id}
            )
            matched += 1
            print(f"  ✓ Linked (late): '{gen_loc.name}'  [generic:{gen_loc.id} ↔ fleet:{fleet_loc.id}]")
        else:
            new_fleet = FleetLoc.with_context(**{SYNC_CTX: True}).create(
                {'name': gen_loc.name}
            )
            gen_loc.with_context(**{SYNC_CTX: True}).write(
                {'fleet_location_id': new_fleet.id}
            )
            created_fleet += 1
            print(f"  + Created fleet.vehicle.location '{gen_loc.name}'  [fleet:{new_fleet.id}]")

print(f"\n  Matched:        {matched}")
print(f"  Created generic: {created_gen}")
print(f"  Created fleet:   {created_fleet}")

# ── STEP 2: Assign location_id to fleet vehicles ────────────────────────
print("\n[2/4] Assigning location_id to fleet vehicles...")

vehicles = Vehicle.search([('location_id', '=', False)])
assigned = 0
skipped  = 0

for vehicle in vehicles:
    # fleet.vehicle already has a location field (fleet.vehicle.location)
    # stored in the standard `location_id` column BEFORE our override.
    # After our module installs, our location_id is now generic.location.
    # We need to read the OLD fleet location and find the matching generic one.

    # Try reading the old fleet location value via the mirror field
    old_fleet_loc = vehicle.fleet_location_mirror_id
    if not old_fleet_loc:
        # Try by the vehicle's state or any other location hint
        skipped += 1
        continue

    gen_loc = GenLoc.search(
        [('fleet_location_id', '=', old_fleet_loc.id)], limit=1
    )
    if gen_loc:
        vehicle.with_context(**{SYNC_CTX: True}).write(
            {'location_id': gen_loc.id}
        )
        assigned += 1
    else:
        skipped += 1

print(f"  Assigned location_id: {assigned}")
print(f"  Skipped (no match):   {skipped}")

# ── STEP 3: Verify integrity ─────────────────────────────────────────────
print("\n[3/4] Integrity check...")

unlinked_gen   = GenLoc.search([('fleet_location_id', '=', False)])
unlinked_fleet = FleetLoc.search([
    ('id', 'not in', GenLoc.search([]).mapped('fleet_location_id').ids)
])

if unlinked_gen:
    print(f"  ⚠ {len(unlinked_gen)} generic.location(s) have no fleet mirror:")
    for g in unlinked_gen[:10]:
        print(f"    - [{g.id}] {g.name}")
else:
    print("  ✓ All generic.location records have a fleet mirror")

if unlinked_fleet:
    print(f"  ⚠ {len(unlinked_fleet)} fleet.vehicle.location(s) have no generic counterpart:")
    for f in unlinked_fleet[:10]:
        print(f"    - [{f.id}] {f.name}")
else:
    print("  ✓ All fleet.vehicle.location records have a generic counterpart")

# ── STEP 4: Commit ──────────────────────────────────────────────────────
print("\n[4/4] Committing...")
env.cr.commit()
print("\n✓ Initial sync complete.\n")
print("=" * 60)

# ═══════════════════════════════════════════════════════════════════════════
# RESOURCE SYNC SECTION
# ═══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 60)
print("NRS Fleet → Resource Initial Sync")
print("=" * 60)

FLEET_SYNC_CTX = 'nrs_fleet_resource_sync_in_progress'

FleetTag    = env['fleet.vehicle.tag']
ResCategory = env['generic.resource.category']
FleetVeh    = env['fleet.vehicle']
GenResource = env['generic.resource']
IrModelData = env['ir.model.data']
IrModel     = env['ir.model']
ResType     = env['generic.resource.type']

# ── STEP A: Create parent category ──────────────────────────────────────
print("\n[A] Ensuring 'NRS Fleet Vehicles' parent resource category...")
try:
    parent_cat = env.ref('nrs_location_sync.resource_category_nrs_fleet')
    print(f"  ✓ Exists: id={parent_cat.id}")
except ValueError:
    parent_cat = ResCategory.with_context(**{FLEET_SYNC_CTX: True}).create(
        {'name': 'NRS Fleet Vehicles'}
    )
    IrModelData.create({
        'name': 'resource_category_nrs_fleet',
        'module': 'nrs_location_sync',
        'model': 'generic.resource.category',
        'res_id': parent_cat.id,
        'noupdate': True,
    })
    print(f"  + Created: id={parent_cat.id}")

# ── STEP B: Create resource type for fleet.vehicle ──────────────────────
print("\n[B] Ensuring 'NRS Fleet Vehicle' resource type...")
try:
    res_type = env.ref('nrs_location_sync.resource_type_fleet_vehicle')
    print(f"  ✓ Exists: id={res_type.id}")
except ValueError:
    fleet_model = IrModel.search([('model', '=', 'fleet.vehicle')], limit=1)
    if fleet_model:
        res_type = ResType.with_context(**{FLEET_SYNC_CTX: True}).create({
            'name': 'NRS Fleet Vehicle',
            'model_id': fleet_model.id,
        })
        IrModelData.create({
            'name': 'resource_type_fleet_vehicle',
            'module': 'nrs_location_sync',
            'model': 'generic.resource.type',
            'res_id': res_type.id,
            'noupdate': True,
        })
        print(f"  + Created: id={res_type.id}")
    else:
        print("  ✗ fleet.vehicle model not found — skipping")
        res_type = None

# ── STEP C: Sync fleet.vehicle.tag → generic.resource.category ──────────
print("\n[C] Syncing vehicle tags → resource categories...")
tags = FleetTag.search([])
tag_synced = 0
for tag in tags:
    if tag.resource_category_id:
        print(f"  ✓ Already linked: '{tag.name}' [tag:{tag.id} ↔ cat:{tag.resource_category_id.id}]")
        tag_synced += 1
        continue
    # Find or create matching category under parent
    existing_cat = ResCategory.search([
        ('name', '=', tag.name),
        ('parent_id', '=', parent_cat.id),
    ], limit=1)
    if existing_cat:
        tag.with_context(**{FLEET_SYNC_CTX: True}).write(
            {'resource_category_id': existing_cat.id}
        )
        print(f"  ✓ Matched: '{tag.name}' [tag:{tag.id} ↔ cat:{existing_cat.id}]")
    else:
        new_cat = ResCategory.with_context(**{FLEET_SYNC_CTX: True}).create({
            'name': tag.name,
            'parent_id': parent_cat.id,
        })
        tag.with_context(**{FLEET_SYNC_CTX: True}).write(
            {'resource_category_id': new_cat.id}
        )
        print(f"  + Created category '{tag.name}' [cat:{new_cat.id}]")
    tag_synced += 1

print(f"  Total tags processed: {tag_synced}")

# ── STEP D: Sync fleet.vehicle → generic.resource ───────────────────────
print("\n[D] Syncing fleet vehicles → generic resources...")
vehicles = FleetVeh.search([])
veh_linked = 0
veh_created = 0

for vehicle in vehicles:
    if vehicle.resource_id:
        veh_linked += 1
        continue

    # Determine category from first tag
    category = None
    for tag in vehicle.tag_ids:
        if tag.resource_category_id:
            category = tag.resource_category_id
            break
    if not category:
        category = parent_cat

    # Build name
    parts = []
    if vehicle.brand_id:
        parts.append(vehicle.brand_id.name)
    if vehicle.model_id:
        parts.append(vehicle.model_id.name)
    if vehicle.license_plate:
        parts.append(f"({vehicle.license_plate})")
    name = ' '.join(parts) if parts else (vehicle.name or f"Vehicle {vehicle.id}")

    # Check if a resource already references this vehicle
    existing_res = GenResource.search([
        ('resource_ref', '=', f'fleet.vehicle,{vehicle.id}')
    ], limit=1)

    if existing_res:
        vehicle.with_context(**{FLEET_SYNC_CTX: True}).write(
            {'resource_id': existing_res.id}
        )
        veh_linked += 1
    else:
        res_vals = {
            'name': name,
            'category_id': category.id,
        }
        if res_type:
            res_vals['resource_type_id'] = res_type.id
            res_vals['resource_ref'] = f'fleet.vehicle,{vehicle.id}'
        new_res = GenResource.with_context(**{FLEET_SYNC_CTX: True}).create(res_vals)
        vehicle.with_context(**{FLEET_SYNC_CTX: True}).write(
            {'resource_id': new_res.id}
        )
        veh_created += 1

print(f"  Vehicles already linked: {veh_linked}")
print(f"  Resources created:       {veh_created}")

# ── STEP E: Commit ──────────────────────────────────────────────────────
print("\n[E] Committing resource sync...")
env.cr.commit()
print("\n✓ Fleet → Resource initial sync complete.")
print("=" * 60)
